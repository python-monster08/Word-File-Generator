from django.urls import path
from .views import display_questions

urlpatterns = [
    path('questions/', display_questions, name='display-questions'),
]
