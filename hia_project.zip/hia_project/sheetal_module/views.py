from django.shortcuts import render
from question_module.models import Question
# Create your views here.


def display_questions(request):
    questions = Question.objects.all()  # Fetch all questions from the database
    return render(request, 'sheetal_module/questions_display.html', {'questions': questions})